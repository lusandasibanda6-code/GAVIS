JARVIS PHONE-ONLY STARTER — SAMSUNG GALAXY A35

WHAT THIS IS
A mobile-first JARVIS web app. It is not an APK yet. It has a reactor-style home screen, suit diagnostics, system page, clock, basic commands, browser speech recognition and spoken replies where supported.

IMPORTANT
For reliable microphone access and Add to Home screen installation, the app must be served from HTTPS (not opened as a plain file:// page). The easiest phone-only route is to publish this folder as a static website using a hosting service such as GitHub Pages or Netlify. A free account may be required. Do not add secret API keys to this front-end.

PHONE-ONLY ROUTE (GitHub Pages)
1. Download and extract JARVIS_A35_Phone.zip using Samsung My Files.
2. In Chrome, sign in to GitHub and create a new public repository named jarvis-a35.
3. Use Add file > Upload files and upload index.html, manifest.webmanifest, sw.js, the icons folder, and README-PHONE.txt from the extracted folder. Commit the upload.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. Wait for the Pages URL to appear. Open it in Chrome on your A35.
7. Chrome menu (⋮) > Add to Home screen (or Install app if offered).
8. Allow microphone permission when asked. Test "What time is it?" and "What is your status?"

If GitHub's mobile page does not show folder upload controls, use GitHub in Chrome's Desktop site mode or upload the ZIP contents with a file manager that can select multiple files. Do not upload only the ZIP; Pages needs the extracted files in the repository root.

VOICE SUPPORT
Chrome on Android may support Web Speech recognition, but availability depends on browser/version and network services. If voice does not work, use the text command box. Text-to-speech uses the phone's speech engine.

CURRENT COMMANDS
hello, time, date, who are you, status, help, open YouTube, open Google.

LIMITS
This is an early prototype, not a native Android app. It cannot silently control settings, read notifications, send messages, change alarms, monitor CPU, or run a background wake phrase. Those require a native Android implementation, Android permissions, and user-approved actions. AI chat is not connected in this build; we'll add that safely in a later stage.
